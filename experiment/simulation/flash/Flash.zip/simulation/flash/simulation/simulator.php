<script src="Scripts/swfobject_modified.js" type="text/javascript"></script>
<div class="post" align="left">&nbsp; <!--leave this space as such.. som wired issue-->
<?php include('breadcum.php'); ?>

  <blockquote> 
    <span class="title">Group_theory</span>
    
	<p>    <div class="postConentPadding">
	  <?php
		//@include('vlab/'.$sub.'/'.$brch.'/'.$sim.'/menu.php');
		@include('menu.php');

?>
</p>
<p align="center"><iframe src="<?= 'vlab/'.$sub.'/'.$brch.'/'.$sim.'/'.'Group_theory.html'?>" frameborder="0" height="600" width="800" scrolling="no"></iframe></p>
  

</blockquote>&nbsp;
</div>
