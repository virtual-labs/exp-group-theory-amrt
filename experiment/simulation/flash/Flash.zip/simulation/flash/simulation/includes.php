<link  href="<?php getSimCss('simstyle.css'); ?>" rel="stylesheet" type="text/css" />
<script src="<?php getSimPath(); ?>js/three.min.js" language="javascript"></script>
<script src="<?php getSimPath(); ?>js/loaders/ColladaLoader.js"></script>
<script src="<?php getSimPath(); ?>js/Detector.js"></script>
<script src="<?php getSimPath(); ?>js/lib/prototype.js" type="text/javascript"></script>
<script src="<?php getSimPath(); ?>js/src/scriptaculous.js" type="text/javascript"></script>


