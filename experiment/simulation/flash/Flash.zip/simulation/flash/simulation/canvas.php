<script type="text/javascript" language="javascript">
	var simPath="<?php getSimPath(); ?>";</script>
<!-- Loading main file   --> 
<script type="text/javascript" src="<?php getSimPath(); ?>js/simcontrols.js"></script>


